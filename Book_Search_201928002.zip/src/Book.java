
public class Book {
	private String bookEntry;

	public String getBookEntry() {
		return bookEntry;
	}

	public void setBookEntry(String bookEntry) {
		this.bookEntry = bookEntry;
	}

	public Book(String bookEntry) {
		super();
		this.bookEntry = bookEntry;
	}
}
